﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web.Http;
using AE.CoreUtility;
using Challenge;
using Newtonsoft.Json;

namespace WebAPI.Controllers
{
    public class UserController : ApiController
    {
        
        // User: api/user/{username} UserInfo GetAddUser(string usernm)
        [HttpGet]
        public string user(string username)
        {
            var UI = new UserInfo();
            UI = BlobIO.GetAddUser(username);

            var json = JsonConvert.SerializeObject(UI);
            return json;
         
        }

    }
}
