using System;
using System.Collections.Generic;
using System.Text;

namespace Challenge
{
    [Serializable]
    public class UserPermissions
    {
        public string Permissions { get; set; }
    }
        
    public class UserInfo
    {
        public string UserName { get; set; }

        public List<UserPermissions> PermissionList { get; set; }

        public DateTime CreateDate { get; set; }

        public TimeZoneInfo UserTimeZone { get; set; }

        public String FavoriteColor { get; set; }
    }


}
